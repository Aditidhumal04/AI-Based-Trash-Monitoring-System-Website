/**
 * (function(){

	
			
			// For Firebase JS SDK v7.20.0 and later, measurementId is optional
			const firebaseConfig = {
			  apiKey: "AIzaSyAqDfFjl7Rq0D6ajwSYv_sTyY7PJn_hmfo",
			  authDomain: "aiiot-1102b.firebaseapp.com",
			  databaseURL: "https://aiiot-1102b-default-rtdb.firebaseio.com",
			  projectId: "aiiot-1102b",
			  storageBucket: "aiiot-1102b.appspot.com",
			  messagingSenderId: "218868565542",
			  appId: "1:218868565542:web:df5361ff8fcc34ee4c88e7",
			  measurementId: "G-VQ6XQLXV1M"
			};	
			
			
firebase.initializaApp(firebaseConfig);
	
	
	const txtUsername=document.getElementById('txtUsername');
	const txtPass=document.getElementById('txtPass');
	const btnLogin=document.getElementById('btnLogin');
	
	btnLogin.addEventListener('click',e => {
		
	
	const username=txtUsername.value;
	const pass=txtPassword.value;
	const auth=firebase.auth();
	
	const promise=auth.signInWithUsernameAndPassword(username,pass);
	promise.catch(e=>console.log(e.message));
	});
}());
 * 
 * 
 * 
 */



